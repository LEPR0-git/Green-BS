require('dotenv').config();
const { uploadImage } = require('../src/services/cloudinaryService');

// ⚠️ Remplace par une image qui existe dans ton dossier uploads/
// (celle que tu viens d'uploader avec Multer)
const TEST_FILE = 'uploads/photo-1790130529301-733170229.jpg';

(async () => {
  try {
    console.log('🔄 Upload en cours...');
    const result = await uploadImage(TEST_FILE);
    console.log('✅ Upload réussi :');
    console.log(JSON.stringify(result, null, 2));
  } catch (error) {
    console.error('❌ Erreur :', error.message);
  }
})();
