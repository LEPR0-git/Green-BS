require('dotenv').config();
const cloudinary = require('../src/config/cloudinary');

console.log('========================================');
console.log('🔍 DEBUG CLOUDINARY:');
console.log('CLOUD_NAME:', process.env.CLOUDINARY_CLOUD_NAME);
console.log('API_KEY:', process.env.CLOUDINARY_API_KEY ? '✅ défini' : '❌ manquant');
console.log('API_SECRET:', process.env.CLOUDINARY_API_SECRET ? '✅ défini' : '❌ manquant');
console.log('========================================');

cloudinary.api.ping()
  .then((result) => {
    console.log('✅ Cloudinary connection OK');
    console.log('📦 Réponse complète:', JSON.stringify(result, null, 2));
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Cloudinary connection error');
    console.error('Message:', error.message);
    console.error('Code HTTP:', error.http_code);
    console.error('Erreur complète:', JSON.stringify(error, null, 2));
    process.exit(1);
  });