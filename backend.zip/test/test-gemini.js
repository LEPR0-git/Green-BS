require('dotenv').config();
const { GoogleGenAI } = require('@google/genai');
const fs = require('fs');

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

// Convertit un fichier local en "part" Gemini
function fileToGenerativePart(path, mimeType) {
  return {
    inlineData: {
      data: Buffer.from(fs.readFileSync(path)).toString('base64'),
      mimeType: mimeType
    }
  };
}

async function analyserImage(imagePath = 'photo.jpg') {
  console.log('🔍 Préparation de l\'image...');
  const imagePart = fileToGenerativePart(imagePath, 'image/jpeg');

  // Prompt structuré pour GreenApp
  const prompt = `Tu es un expert en gestion des déchets urbains. Analyse cette image et réponds UNIQUEMENT avec un objet JSON valide, sans texte avant ni après.

Critères d'analyse :
- isWaste : true si l'image montre des déchets (bac plein, dépôt sauvage, déchets au sol), false sinon
- confidence : ton niveau de certitude entre 0.0 et 1.0
- type : parmi "bac_plein", "depot_sauvage", "dechets_au_sol", "autre"
- description : une phrase courte décrivant ce que tu vois

Format de réponse attendu (JSON strict) :
{
  "isWaste": true,
  "confidence": 0.87,
  "type": "depot_sauvage",
  "description": "Un tas de déchets plastiques au bord d'une route"
}`;

  console.log('📡 Appel de Gemini 2.0 Flash...');
  const response = await ai.models.generateContent({
    model: 'gemini-3.6-flash',
    contents: [prompt, imagePart]
  });

  console.log('\n=== Réponse brute ===');
  console.log(response.text);

  // Tentative de parsing JSON
  try {
    const cleaned = response.text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(cleaned);
    console.log('\n=== Réponse parsée ===');
    console.log(JSON.stringify(parsed, null, 2));
  } catch (err) {
    console.error('\n❌ Impossible de parser la réponse en JSON:', err.message);
  }
}

analyserImage(process.argv[2] || 'photo.jpg').catch(console.error);