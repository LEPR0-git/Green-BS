require('dotenv').config();
const express = require('express');
const upload = require('../src/middlewares/upload');

const app = express();

app.post('/test-upload', upload.single('photo'), (req, res) => {
  console.log('File:', req.file);
  console.log('Body:', req.body);

  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  res.json({
    message: 'File uploaded successfully',
    file: {
      filename: req.file.filename,
      size: req.file.size,
      mimetype: req.file.mimetype,
      path: req.file.path
    },
    body: req.body
  });
});

app.listen(3001, () => {
  console.log('Test server on http://localhost:3001');
});